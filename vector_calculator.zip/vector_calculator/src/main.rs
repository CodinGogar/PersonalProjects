
use std::io;


fn insert_vector()->(Vec<u64>, Vec<u64>){

//to store the two vectors
let mut input1 : Vec<u64> = Vec::new();
let mut input2 : Vec<u64> = Vec::new();

println!("INPUT 2 VECTORS ");

println!("The first vector");
  let mut vec1 = String::new();
  io::stdin().read_line(&mut vec1)
  .expect("failed  to read vec1");

// store it in input1
  input1.extend(vec1.split_whitespace().map(|s| s.trim().parse::<u64>().expect("Invalid number at vec1")));
println!("The second vector");
  let mut vec2 = String::new();
  io::stdin().read_line(&mut vec2)
  .expect("failed to read vec2");

  input2.extend(vec2.split_whitespace().map(|s| s.trim().parse::<u64>().expect("invalid number at vec2")));
// returns vectors as a tuple
(input1, input2)

}

fn main () {
    println!("HEY THERE!");
    println!("\n WELCOME TO VECTOR CALCULATOR");
    println!("\n WHAT WOULD YOU LIKE TO CALCULATE");
    println!("1.Input vectors from the user.
    \n 2.Perform vector addition and subtraction.
    \n 3.Perform scalar multiplication of vectors.
    \n 4.Calculate the dot product of two vectors.
    \n 5.Calculate the cross product of two vectors (optional if you want to include this).
    \n 6.Calculate the magnitude (length) of a vector.
    \n 7.Calculate the angle between two vectors.
    \n 8.Determine if two vectors are orthogonal (perpendicular) or parallel.");

 

let mut choice = String::new();
io::stdin().read_line(&mut choice)
.expect("failed to read choice");

// parse the choice string to an integer
 let choice_parsed:i32 = choice.trim().parse()
.expect("parsing choice failed"); 


let ( first_vec, second_vec) = insert_vector(); // Call the function to get both input vectors

let mut prod:i32 = 0;
let mut multip:i32 = 0;
let mut dot_prod:f64 = 0.0;
let mut modulus_a:f64 = 0.0;
let mut mudolos_b:f64 = 0.0;
let mut ang:f64 = 0.0;

/*loop 1*/
if choice_parsed == 2 {

  // assert_eq checks if two vectors are equal
  assert_eq!(first_vec.len(), second_vec.len(), "Vectors must have the same length");

for x in 0..first_vec.len(){

println!("the sum is ");
let sum = first_vec[x] + second_vec[x];
println!("{:?}", sum);

println!("The difference is ");
let diff = first_vec[x] - second_vec[x];
println!("{:?}", diff);
}
/* End of loop 1*/}

/*loop 2*/else if choice_parsed == 3 {
  println!("What scalar do you want to multiply by");
  let mut sca = String::new();
  io::stdin().read_line(&mut sca)
  .expect("failed to read  sca");

  let  scalar:i32 = sca.trim().parse().expect("Parsing  sca failed");
    
println!("Which vector  are you multiplying the  scalar by
 choose 1 for the first vector or 2 for the second vector
 or 3 for both vectors.");

let mut input3 = String::new();
io::stdin().read_line(&mut input3)
.expect("failed to read input3");



/*sub1 loop 2*/
if input3 == "1" {
    // Iterate over the elements of first_vec using .iter()
    for &i in first_vec.iter() {
        // Inside the loop, update the value of prod
        prod = (scalar as i32) * (i as i32);
        println!("{:?}", prod);
    }
/*End sub1 loop 2*/}



/*sub2 loop 2*/
else if input3 == "2"{
  for &p in second_vec.iter(){
   multip = (scalar as i32) * (p as i32);
    println!("{:?}",multip);
  }
/*End sub2 loop 2*/}
else if input3 == "3"{
println!("{} and {}",prod,multip);
}
/*End of loop 2*/} 


/*loop3*/
else if choice_parsed == 4 {
  println!("Dot product formula: |a||b|cos#");
for s in 0..first_vec.len()        /*Sub loop */{
modulus_a +=  first_vec[s] as f64 * first_vec[s] as f64;
mudolos_b += second_vec[s] as f64 * second_vec[s] as f64;

modulus_a = modulus_a.sqrt();
mudolos_b = mudolos_b.sqrt();
/*end of Sub loop */}

println!("what is the angle");
let mut input4 = String::new();
io::stdin().read_line(&mut input4).expect("failed to read  input 4");

let angle:f64 = input4.trim().parse().expect("Parsing failed");
let angle_rad:f64 = angle.to_radians();
 let cos_val:f64 = angle_rad.cos();

dot_prod = (modulus_a * mudolos_b) * cos_val;
println!("The dot prod is {}",dot_prod);

/*End of loop3*/}

/*start of loop4*/
else if choice_parsed == 6{
println!("The magnitude of these vectors are {} and {}", modulus_a, mudolos_b);
}
/*End of loop4*/


/*start of loop5*/
else if choice_parsed == 7 {
  println!("Formula for angle: cos# = a.b/|a|x|b|");

   ang =(dot_prod as f64) / (modulus_a as f64) * (mudolos_b as f64);     

  println!("The angle is {}", ang);
}
/*End of loop5*/


/*start of loop6*/

else if choice_parsed == 8 {
  println!("NOTE:  if two vectors are perpendicular then the angle between them is 90. If  two vectors
  are parallel then the angle  between them is 0");
if ang == 0.0{
  println!("These two vectors are parallel");
}

else if ang == 90.0{
  println!("These two vectors are perpendicular");

}

else {
  println!("The angle  between these vectors is {} hence nothing special", ang);
}

}
/*End of loop6*/



} 
/*
let 1ref = &first_vec[index];
let 2ref = &second_vec[index];

let vec_sum =first_ref + second_ref;
*/